## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(graphics)
library(SIRSimulation)

## -----------------------------------------------------------------------------
# Matrix with 25% chance of each cell starting infected
x <- create_matrix(5,5,0.25)

## -----------------------------------------------------------------------------
# corners infected matrix
corners <- create_crnr_matrix(5,5)

# Center infected matrix
center <- create_cntr_matrix(15,15)

## -----------------------------------------------------------------------------
# Run a basic simulation on matrix x
# Set probability of infection to 0.25
# Use default values auto_immunity FALSE and allow_death FALSE
# Since auto_immunity is FALSE, this will use the default immunity probability value of 0.5
simulate_sir(0.25,x)

## -----------------------------------------------------------------------------
# Run a basic simulation on matrix x
# Set probability of infection to 0.25
# Use default values auto_immunity FALSE and allow_death FALSE
# Set value for immunity probability to 0.34
simulate_sir(0.25,x,FALSE,0.34)

## -----------------------------------------------------------------------------
# Run a basic simulation on matrix x
# Set probability of infection to 0.25
# Set auto_immunity to TRUE and use default value of allow_death FALSE
simulate_sir(0.25,x,TRUE)

## -----------------------------------------------------------------------------
# Run a basic simulation on matrix x
# Set probability of infection to 0.25
# Set auto_immunity to TRUE and immunity probability to 0.0
# Set allow_death to TRUE and fatality probability to 0.19
simulate_sir(0.25,x,TRUE,0.0,TRUE,0.19)

## -----------------------------------------------------------------------------
# Run a basic simulation on matrix x
# Set probability of infection to 0.25
# Set auto_immunity to FALSE and immunity probability to 0.35
# Set allow_death to TRUE and fatality probability to 0.12
simulate_sir(0.25,x,FALSE,0.35,TRUE,0.12)

## -----------------------------------------------------------------------------
# Run the sequence of infection probabilities using the basic simulation on matrix x from above
# Set step in sequence to 0.1
simulate_inf_seq(x,0.1)

## -----------------------------------------------------------------------------
# Run a basic simulation on matrix x many times and report average statistics
# Set probability of infection to 0.25
# Set number of runs to 2
simulate_many_runs(0.25,x,2)

## -----------------------------------------------------------------------------
# Run a basic simulation on matrix x many times and generate heatmap
# Set probability of infection to 0.25
# Set number of runs to 2
multiple_run_heatmap(0.25,x,2)

